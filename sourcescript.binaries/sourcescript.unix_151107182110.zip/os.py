import os
import platform
print("OS Name: ", os.name, " - ", platform.system());
print("OS Version: ", platform.release());

